<?php
//Create a registration page with OOP
class Register {
	
}