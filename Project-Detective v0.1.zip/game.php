<?php

class Game{
	
	public $locations;
	public $endGame;
	
	public function __construct($endgame){
		$this->endgame = $endgame;
		$locations = array();
	}
	
	public function _newGame(){
		$this->location = $location;
		
	}
}