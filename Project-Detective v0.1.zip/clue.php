<?php

Class clue {
	
	public $areaID;
	public $suspectID;
	
	public function setCulpritChance($suspArea){

	}
}